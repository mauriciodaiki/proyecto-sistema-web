export const users = [
    { id: 1, name: "Sergio Ulises Lillingston Pérez", role: "Administrador", email: "asesor@udgvirtual.mx" },
    { id: 2, name: "José Alberto Rodriguez Lara", role: "Desarrollador" },
    { id: 3, name: "Mauricio Daiki Rascon Yamamoto", role: "Desarrollador" },
    { id: 4, name: "Raymundo Chavarria Serratos", role: "Desarrollador" },
];
